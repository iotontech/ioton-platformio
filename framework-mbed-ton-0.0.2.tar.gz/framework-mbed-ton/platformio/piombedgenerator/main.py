# Copyright 2014-present PlatformIO <contact@platformio.org>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import argparse
from os import mkdir
from os.path import isdir, isfile, join, basename
from sys import exit as sys_exit
from shutil import copyfile, rmtree
from tempfile import mkdtemp
from subprocess import call


def get_mbed_targets():
    targets_file = join("..", "hal", "targets.json")
    assert targets_file
    with open(targets_file) as fp:
        targets_data = json.load(fp)

    targets = list()
    for target in targets_data:
        release_versions = targets_data.get(
            target, {}).get("public", True)
        if release_versions:
            targets.append(target)
    return targets


def main(targets):
    print "Starting..."
    assert isfile(join("../", "tools", "project.py"))
    if not targets:
        targets = get_mbed_targets()

    if isdir("variants"):
        print "Deleting previous targets..."
        rmtree("variants")
    mkdir("variants")

    correct_targets = []
    for target in targets:
        print "Generating configuration file for %s" % target
        tmp_dir = mkdtemp()
        with open("export.log", "a") as fp:
            result = call(
                [
                    "python", join("../", "tools", "project.py"),
                    "-m", target, "-i", "emblocks", "--source", tmp_dir
                ], stdout=fp
            )

        if result != 0:
            print("* Skipped target: %s" % target)
            continue

        temp_prj_file = join(tmp_dir, basename(tmp_dir) + ".eix")
        prj_file = join("variants", "%s.eix" % target)

        if isfile(prj_file):
            continue

        if not isfile(temp_prj_file):
            print("* Warning! Skipped target: %s" % target)
        else:
            copyfile(temp_prj_file, prj_file)
            correct_targets.append(target)
        rmtree(tmp_dir)

    with open(join("variants", "targets.txt"), "w") as fp:
        fp.write("\n".join(correct_targets))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--targets', nargs='*', help="Specify necessary mbed target")
    args = vars(parser.parse_args())
    sys_exit(main(args["targets"]))
