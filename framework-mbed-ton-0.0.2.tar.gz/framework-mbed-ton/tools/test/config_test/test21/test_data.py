# Testing basic features

expected_results = {
    "test_target": {
        "desc": "test basic features",
        "expected_features": ["IPV4", "IPV6"]
    }
}
