#include "mbed.h"

#if !DEVICE_PORTOUT
  #error [NOT_SUPPORTED] PortOut is not supported
#endif

# if defined(TARGET_LPC1768) || defined(TARGET_LPC2368) || defined(TARGET_LPC4088) || defined(TARGET_LPC2460)
#     define LED_PORT   Port1
#     define LED1       (1 << 18) // P1.18
#     define LED2       (1 << 20) // P1.20
#     define LED3       (1 << 21) // P1.21
#     define LED4       (1 << 23) // P1.23
# elif defined(TARGET_LPC11U24) || defined(TARGET_LPC1114)
#     define LED_PORT   Port1
#     define LED1       (1 <<  8) // P1.8
#     define LED2       (1 <<  9) // P1.9
#     define LED3       (1 << 10) // P1.10
#     define LED4       (1 << 11) // P1.11
# elif defined(TARGET_MAXWSNENV)
#     define LED_PORT   Port1
#     define LED1   (1 <<  4) // P1.4
#     define LED2   (1 <<  6) // P1.6
#     define LED3   (1 <<  7) // P1.7
#     define LED4   0
# elif defined(TARGET_MAX32600MBED)
#     define LED_PORT   Port7
#     define LED1       (1 <<  0) // P7.0
#     define LED2       (1 <<  6) // P7.6
#     define LED3       (1 <<  4) // P7.4
#     define LED4       0
# elif defined(TARGET_SAMR21G18A)
#     define LED_PORT   PortA
#     define LED1       (1 <<  19) /*PA19*/
#     define LED2       0
#     define LED3       0
#     define LED4       0
# elif defined(TARGET_SAMD21J18A)
#     define LED_PORT   PortB
#     define LED1       (1 <<  30) /*PB30*/
#     define LED2       0
#     define LED3       0
#     define LED4       0
# elif defined(TARGET_SAMD21G18A)
#     define LED_PORT   PortA
#     define LED1       (1 <<  23) /*PA23*/
#     define LED2       0
#     define LED3       0
#     define LED4       0
# elif defined(TARGET_SAML21J18A)
#     define LED_PORT   PortB
#     define LED1       (1 <<  10) /*PB10*/
#     define LED2       0
#     define LED3       0
#     define LED4       0
# elif defined(TARGET_SAMG55J19)
#     define LED_PORT   PortA
#     define LED1       (1 <<  6) /*PA06*/
#     define LED2       0
#     define LED3       0
#     define LED4       0
# else
  #error [NOT_SUPPORTED] This test can't be ran on this target
#endif


#define LED_MASK    (LED1|LED2|LED3|LED4)

int mask[4] = {
    (LED1 | LED3),
    (LED2 | LED4),
    (LED1 | LED2),
    (LED3 | LED4)
};

PortOut ledport(LED_PORT, LED_MASK);

int main() {
    while (1) {
        for (int i=0; i<4; i++) {
            ledport = mask[i];
            wait(1);
        }
    }
}
